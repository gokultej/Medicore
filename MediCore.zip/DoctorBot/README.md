# DoctorBot
A Bot that offers medical assistance. Built with flask


**To see this app live, visit:** https://doctor-bot.herokuapp.com  

**To run locally:**  
>  mkdir doctor-bot  
  cd doctor-bot  
  git clone https://github.com/mirakul1/doctor-bot.git  

>  pip -r requirements.txt  

>  python app.py  

Goto `localhost:5000` to view your web app.

