# Appointment-System
a flask framework project for appointment booking of different hospitals.

# Technologies Used
- Flask
- HTML
- CSS
- PYTHON

# Features
- stores patient details
- stores doctors appontment detail
- can be retrived as per request of the user(doctor/patient).
